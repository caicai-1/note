package cn.itcast.thread;
import java.util.concurrent.locks.ReentrantReadWriteLock;

// ReentrantReadWriteLock: 可重入读写锁 (读锁是共享锁，写锁是独享锁)
public class Test11 {

    // 定义可重入读写锁
    private ReentrantReadWriteLock rw = new ReentrantReadWriteLock();

    public static void main(String[] args)  {
        final Test11 test = new Test11();

        new Thread(() -> {
            test.get(Thread.currentThread());
        }).start();

        new Thread(() -> {
            test.get(Thread.currentThread());
        }).start();
    }

    public  void get(Thread thread) {
        // 读锁是共享锁
        rw.readLock().lock();
        // 写锁是独享锁
        //rw.writeLock().lock();
        try {
            for (int i = 0; i < 50; i++){
                System.out.println(thread.getName() + "正在进行读操作");
            }
            System.out.println(thread.getName() + "读操作完毕");
        }finally {
            rw.readLock().unlock();
            //rw.writeLock().unlock();
        }
    }
}