package cn.itcast.thread;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Test12 implements Runnable {

    // 定义整型并发原子对象
    private static AtomicInteger atomicInteger = new AtomicInteger(0);

    @Override
    public void run() {
        try {
            // 线程休眠
            Thread.sleep(200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // 进行原子性操作+1
        System.out.println(atomicInteger.incrementAndGet());
    }

    public static void main(String[] args) throws InterruptedException {
        // 创建List集合
        List<Thread> list = new ArrayList<>();
        Test12 task = new Test12();

        // 开启多线程进行操作共享变量
        for (int i = 0; i <10 ; i++) {
            Thread thread = new Thread(task);
            list.add(thread);
            thread.start();
        }

        for (Thread thread : list) {
            thread.join(); // 确保所有thread全部运行
        }

        System.out.println("递增结果：" + atomicInteger.get());
    }
}