package cn.itcast.thread;

public class Test5 {
    // 定义flag属性
    private static boolean flag = false;

    public static void main(String[] args) throws InterruptedException {

        // 创建线程1
        new Thread(() -> {
            long num = 0;
            while (!flag){
                num++;
            }
            // 如果没有打印，说明当前线程无法感知flag的修改
            System.out.println("num = " + num);
        }).start();

        // 休眠1000毫秒
        Thread.sleep(1000);

        // 创建线程2
        new Thread(() -> {
            // 修改flag
            flag = true;
            System.out.println("flag = " + flag);
        }).start();
    }
}