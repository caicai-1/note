package cn.itcast.thread;

import java.util.concurrent.atomic.AtomicReference;


public class Test14 {

    public static void main(String[] args) {

        // 1. 创建一个User对象封装数据
        User user = new User("李小华", 18);

        // 2. 创建一个原子引用类型AtomicReference操作User类型数据
        AtomicReference<User> atomicReference = new AtomicReference<>();

        // 3. 将user对象的数据存入原子引用类型对象中
        atomicReference.set(user);
        // 4. 更新原子引用类型存储的数据
        atomicReference.compareAndSet(user, new User("李中华", 20));

        // 5. 打印普通user对象数据与原子引用类型对象数据
        System.out.println("普通对象数据："+ user +",对象hashcode: " + user.hashCode());
        System.out.println("原子引用类型对象数据：" + atomicReference.get()
                + ",对象hashcode: " + atomicReference.get().hashCode());
    }
}