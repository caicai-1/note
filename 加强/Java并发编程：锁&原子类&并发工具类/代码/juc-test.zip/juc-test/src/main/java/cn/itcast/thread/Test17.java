package cn.itcast.thread;

import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeUnit;

public class Test17 {

    // 定义同步屏障对象
    private static CyclicBarrier cb = new CyclicBarrier(2);

    public static void main(String[] args) {
        // 创建线程1
        new Thread(() -> {
            try {
                System.out.println("达到屏障阻塞线程数：" + cb.getNumberWaiting());
                cb.await(); // 达到屏障阻塞，+1
                System.out.println("运行结束1"); // 不会运行
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();

        // 创建线程2
        new Thread(() -> {
            try {
                System.out.println("达到屏障阻塞线程数：" + cb.getNumberWaiting());
                cb.await(); // 达到屏障阻塞，+1
                System.out.println("运行结束2"); // 不会运行
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();


        try {
            TimeUnit.SECONDS.sleep(2);
            // 会运行，没有到达屏障，不会阻塞
            System.out.println("主线程完成，拦截线程数：" + cb.getParties()
                    + "，达到屏障阻塞线程数：" + cb.getNumberWaiting());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}