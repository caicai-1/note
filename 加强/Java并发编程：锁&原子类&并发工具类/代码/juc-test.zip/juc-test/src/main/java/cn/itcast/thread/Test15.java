package cn.itcast.thread;

public class Test15 {

    public static void main(String[] args) throws InterruptedException {
        // 创建线程1
        Thread t1 = new Thread(() -> {
            System.out.println("parser1 finish");
        });
        // 创建线程2
        Thread t2 = new Thread(() -> {
            System.out.println("parser2 finish");
        });
        t1.start();
        t2.start();
        t1.join();  // join阻塞
        t2.join();  // join阻塞
        System.out.println("join方式: all parser finish");
    }
}