package cn.itcast.thread;

import java.util.concurrent.locks.ReentrantLock;

/** 学习使用Lock解决线程安全问题 */
public class Test10 {

    // 定义票的总数量
    private static int ticket = 100;

    public static void main(String[] args) {
        // 创建可重入锁对象
        ReentrantLock lock = new ReentrantLock();

        Runnable runnable = () -> {
            // 循环卖票
            while (true) {
                try {
                    Thread.sleep(10);
                    // 获得锁
                    lock.lock();
                    if (ticket > 0) {
                        ticket--;
                        System.out.println(Thread.currentThread().getName() +
                                "卖了一张票，剩余：" + ticket);
                    } else {
                        break;
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    // 释放锁
                    lock.unlock();
                }
            }
        };

        // 创建3个线程
        Thread t1 = new Thread(runnable, "窗口1");
        Thread t2 = new Thread(runnable, "窗口2");
        Thread t3 = new Thread(runnable, "窗口3");
        t1.start();
        t2.start();
        t3.start();
    }
}