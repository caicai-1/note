package cn.itcast.thread;

import java.util.concurrent.TimeUnit;

/**
 * 测试 wait()、notify()、notifyAll()
 */
public class Test1 {

    public static void main(String[] args) {
        // 创建对象
        Object obj = new Object();
        // 线程t1
        new Thread(() -> {
            synchronized (obj) {
                try {
                    System.out.println(Thread.currentThread().getName() + "wait 前");
                    obj.wait(); // 等待、线程阻塞(释放锁)
                    System.out.println(Thread.currentThread().getName() + "wait 后");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }, "t1:").start();

        // 线程t2
        new Thread(() -> {
            synchronized (obj) {
                try {
                    System.out.println(Thread.currentThread().getName() + "wait 前");
                    obj.wait(); // 等待、线程阻塞(释放锁)
                    System.out.println(Thread.currentThread().getName() + "wait 后");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }, "t2:").start();

        // 线程t3
        new Thread(() -> {
            synchronized (obj) {
                try {
                    // 休眠2秒
                    TimeUnit.SECONDS.sleep(2);  //目的让前2个线程进入等待状态
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("notifyAll 前");
                obj.notifyAll(); // 唤醒全部等待的线程，不会释放锁
                System.out.println("notifyAll 后");
            }
        }, "t3:").start();
    }
}