package cn.itcast.thread;

import java.util.concurrent.CountDownLatch;

public class Test16 {

    // 定义倒计数闭锁对象
    private static CountDownLatch countDownLatch = new CountDownLatch(2);

    public static void main(String[] args) throws InterruptedException {
        // 创建线程1
        Thread t1 = new Thread(() -> {
            System.out.println("parser1 finish");
            countDownLatch.countDown(); // 计算递减1
        });
        // 创建线程2
        Thread t2 = new Thread(() -> {
            System.out.println("parser2 finish");
            countDownLatch.countDown(); // 计算递减1
        });
        t1.start();
        t2.start();
        countDownLatch.await();  // 阻塞，计算为0释放阻塞，运行后面的代码
        System.out.println("join方式: all parser finish");
    }
}