package cn.itcast.thread;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicIntegerArray;

public class Test13 implements Runnable{

    // 定义数组
    private static int[] ints = {0,2,3};
    // 定义原子整型数组对象
    private static AtomicIntegerArray atomicIntegerArray
            = new AtomicIntegerArray(ints);

    @Override
    public void run() {
        try {
            // 线程休眠
            Thread.sleep(200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // 操作普通数组中的第一个元素 +1
        ints[0] = ints[0] + 1;
        // 操作原子数组中的第一个元素 +1
        System.out.println(atomicIntegerArray.incrementAndGet(0));
    }

    public static void main(String[] args) throws InterruptedException {
        // 创建List集合
        List<Thread> list = new ArrayList<>();
        Test13 task = new Test13();

        // 开启多线程进行操作共享变量
        for (int i = 0; i <10 ; i++) {
            Thread thread = new Thread(task);
            list.add(thread);
            thread.start();
        }

        for (Thread thread : list) {
            thread.join(); // 确保所有thread全部运行
        }

        System.out.println("原子数组操作结果：" + atomicIntegerArray.get(0)); // 10
        System.out.println("普通数组操作结果：" + ints[0]); // 不一定
    }
}