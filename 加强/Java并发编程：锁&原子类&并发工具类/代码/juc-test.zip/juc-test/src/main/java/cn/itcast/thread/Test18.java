package cn.itcast.thread;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class Test18 {

    public static void main(String[] args) {

        // 1. 创建信号量对象控制并发线程数量，设置许可数5个（同时运行5个线程）
        Semaphore semaphore = new Semaphore(5, true);

        // 2. 循环运行10个线程（会看到每次只允许5个线程）
        for (int i = 0; i < 10; i++) {
            new Thread(() -> {
                try {
                    // 2.1 申请获取许可
                    semaphore.acquire();

                    // 2.2 运行业务
                    System.out.println(Thread.currentThread().getName() + "车，进入停车场");
                    TimeUnit.SECONDS.sleep(3);// 让当前线程休眠（让线程多运行一会，方便观察效果）
                    System.out.println(Thread.currentThread().getName() + "车，离开停车场");

                    // 2.3 释放阻塞，增加一个许可（让下一个阻塞的线程运行）
                    semaphore.release();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }
}