package cn.itcast.thread;

/**
 * join() : 加入线程
 * yield() : 线程让步
 * sleep() : 线程休眠
 */
public class Test3 {

    public static void main(String[] args) throws InterruptedException {
        // 线程1
        Thread t1 = new Thread(() -> {
            for (int i = 1; i <= 20; i++) {
                System.out.println(Thread.currentThread().getName() + i);
                // 线程让步
                //Thread.yield();
            }
        },"t1:");

        // 线程2
        Thread t2 = new Thread(() -> {
            for (int i = 1; i <= 20; i++) {
                System.out.println(Thread.currentThread().getName() + i);
            }
        },"t2:");

        // 启动线程
        t1.start();
        // 加入线程
        t1.join();
        // 设置线程优先级
        //t1.setPriority(Thread.MIN_PRIORITY);

        t2.start();
        // 设置线程优先级
        //t2.setPriority(Thread.MIN_PRIORITY);
    }
}