package cn.itcast.thread;

public class Test7 {

    // 无法在多线程的情况下实现原子自递增的问题。
    private static int count = 0;

    // 定义累计的方法
    public synchronized static void inc(){
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        count++;
    }

    public static void main(String[] args) throws InterruptedException {
        // 循环创建线程
        for(int i = 0; i < 1000; i++){
            new Thread(() -> {
                inc();
            }).start();
        }
        Thread.sleep(4000);
        System.out.println("y运行结果："+count);
    }
}