package cn.itcast.thread;

/** 学习死锁的概念和解决死锁 */
public class DeadLock {

    // 定义两个对象作为锁
    private static Object objA = new Object();
    private static Object objB = new Object();

    public static void main(String[] args) {
        // 线程1
        Thread t1 = new Thread(() -> {
            // 同步锁
            synchronized (objA){
                try {
                    // 线程休眠(让出CPU，不释放锁)
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("AAAAAAA");
                // 同步锁
                synchronized (objB){
                    System.out.println("BBBBBBB");
                }
            }
        });

        // 线程2
        Thread t2 = new Thread(() -> {
            // 同步锁
            synchronized (objB){
                System.out.println("CCCCCCC");
                // 同步锁
                synchronized (objA){
                    System.out.println("DDDDDDD");
                }
            }
        });

        t1.start();
        t2.start();
    }
}