package cn.itcast.thread;

/** 测试: 线程6种状态 */
public class Test2 {

    // 方法1 (RUNNABLE: 运行)
    public static void test1() {
        new Thread(() -> {
            synchronized (Test2.class) {
                while (true) {
                }
            }
        }, "t1-runnable").start();  //线程运行中
    }

    // 方法2 (TIMED_WAITING : 超时等待)
    public static void test2() {
        new Thread(() -> {
            synchronized (Test2.class) {
                while (true) {
                    try {
                        Test2.class.wait(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }, "t2-timed_waiting").start(); //线程超时等待中
    }

    // 方法3
    public static void test3() {
        // (RUNNABLE: 运行)
        new Thread(() -> {
            synchronized (Test2.class) {
                while (true) {
                }
            }
        }, "t3-runnable").start();
        // (BLOCKED: 阻塞)
        new Thread(() -> {
            synchronized (Test2.class) {
                //由于上面没有释放锁，被阻塞中
            }
        }, "t4-BLOCKED").start();
    }

    // 方法4 (WAITING : 等待)
    public static void test4() {
        new Thread(() -> {
            synchronized (Test2.class) {
                while (true) {
                    try {
                        Test2.class.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }, "t5-waiting").start(); //线程等待中
    }

    public static void main(String[] args) {
        //test1();  // 线程运行中
        //test2();  // 线程超时等待中
        test3();  // 线程阻塞中
        //test4();    // 线程等待中
    }
}