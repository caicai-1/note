package cn.itcast.thread;

public class Test4 {
    // 定义变量
    private static final long count = 1000000000;

    public static void main(String[] args) throws InterruptedException {
        concurrency();
        serial();
    }

    // 定义方法1(使用线程)
    private static void concurrency() throws InterruptedException {
        long start = System.currentTimeMillis();
        // 创建线程 循环累加
        Thread thread = new Thread(() -> {
            int a = 0;
            for (long i = 0; i < count; i++) {
                a += 5;
            }
        });
        // 开启线程
        thread.start();

        // 循环累减
        int b = 0;
        for (long i = 0; i < count; i++) {
            b--;
        }
        long time = System.currentTimeMillis() - start;
       // thread.join();
        System.out.println("concurrency :" + time + "ms,b=" + b);
    }


    // 定义方法2 (不用线程)
    private static void serial() {
        long start = System.currentTimeMillis();
        // 循环累加
        int a = 0;
        for (long i = 0; i < count; i++) {
            a += 5;
        }
        // 循环累减
        int b = 0;
        for (long i = 0; i < count; i++) {
            b--;
        }
        long time = System.currentTimeMillis() - start;
        System.out.println("serial:" + time + "ms,b=" + b );
    }
}