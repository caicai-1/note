 package cn.itcast.thread;

import java.util.concurrent.Exchanger;

public class Test19 {

    public static void main(String[] args) {

        // 1. 创建交换数据对象，并设置传输数据的类型
        Exchanger<String> exchanger = new Exchanger<>();

        // 2. 启动2个线程进行交换数据
        // 创建线程1
        new Thread(() -> {
            // 2.1 定义交换的数据
            String girl1 = "【柳岩】";
            System.out.println(Thread.currentThread().getName() + "说：我的女友 " + girl1);
            System.out.println(Thread.currentThread().getName() + "说：等待线程2交换数据");
            // 2.2 将数据交换给线程2,并拿到线程2的数据
            try {
                String b = exchanger.exchange(girl1);//注意：如果线程2没有到达同步点，当前线程会被阻塞一直等到
                //成功获取线程2的数据后
                System.out.println(Thread.currentThread().getName() + "说：我拿到了 " + b);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();

        // 创建线程2
        new Thread(()->{
            // 2.3 定义交换的数据
            String girl2 = "【杨幂】";
            System.out.println(Thread.currentThread().getName()+"说：我的女友 " + girl2);
            System.out.println(Thread.currentThread().getName()+"说：等待线程1交换数据");
            // 2.4 将数据交换给线程1,并拿到线程1的数据
            try {
                String a = exchanger.exchange(girl2);
                // 成功获取线程1的数据后
                System.out.println(Thread.currentThread().getName()+"说：我拿到了 " + a);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
}