package cn.itcast;

import cn.itcast.pojo.Account;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.InputStream;

/**
 * 测试类
 */
public class AccountMapperTest01 {

    /** 根据主键id查询 */
    @Test
    public void findOne() throws Exception{
        // 1. 获取全局配置文件输入流
        InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");

        // 2. 创建SqlSessionFactory
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder()
                .build(inputStream);

        // 3. 获取SqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();


        // 4. 用sqlSession执行CRUD
        Account account = sqlSession.selectOne("cn.itcast.mapper.AccountMapper.findOne", 1);
        System.out.println("account = " + account);


        // 5. 关闭sqlSession
        sqlSession.close();
    }


    /** 添加 */
    @Test
    public void save() throws Exception{
        // 1. 获取全局配置文件输入流
        InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");

        // 2. 创建SqlSessionFactory
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder()
                .build(inputStream);

        // 3. 获取SqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();

        // 4. 用sqlSession执行CRUD
        Account account = new Account();
        account.setName("小李");
        account.setMoney(8000f);
        sqlSession.insert("cn.itcast.mapper.AccountMapper.save", account);

        // 5. 提交事务
        sqlSession.commit();

        // 6. 关闭sqlSession
        sqlSession.close();
    }
}
