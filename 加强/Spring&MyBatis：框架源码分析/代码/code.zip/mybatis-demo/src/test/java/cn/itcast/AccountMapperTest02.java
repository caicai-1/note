package cn.itcast;

import cn.itcast.mapper.AccountMapper;
import cn.itcast.pojo.Account;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.InputStream;

/**
 * 测试类
 */
public class AccountMapperTest02 {

    /** 根据主键id查询 */
    @Test
    public void findOne() throws Exception{
        // 1. 获取全局配置文件输入流
        InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");

        // 2. 创建SqlSessionFactory
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder()
                .build(inputStream);

        // 3. 获取SqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();

        // 4. 获取数据访问接口代理对象
        AccountMapper accountMapper = sqlSession.getMapper(AccountMapper.class);
        Account account = accountMapper.findOne(1);
        System.out.println("account = " + account);

        // 5. 关闭sqlSession
        sqlSession.close();
    }


    /** 添加 */
    @Test
    public void save() throws Exception{
        // 1. 获取全局配置文件输入流
        InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");

        // 2. 创建SqlSessionFactory
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder()
                .build(inputStream);

        // 3. 获取SqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();

        // 4. 获取数据访问接口代理对象
        AccountMapper accountMapper = sqlSession.getMapper(AccountMapper.class);
        Account account = new Account();
        account.setName("小李");
        account.setMoney(8000f);
        accountMapper.save(account);

        // 5. 提交事务
        sqlSession.commit();

        // 6. 关闭sqlSession
        sqlSession.close();
    }
}
