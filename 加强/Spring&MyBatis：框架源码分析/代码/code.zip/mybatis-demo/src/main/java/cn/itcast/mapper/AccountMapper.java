package cn.itcast.mapper;

import cn.itcast.pojo.Account;

public interface AccountMapper {

    // 根据主键id查询
    Account findOne(Integer id);

    // 添加账户
    int save(Account account);
}
