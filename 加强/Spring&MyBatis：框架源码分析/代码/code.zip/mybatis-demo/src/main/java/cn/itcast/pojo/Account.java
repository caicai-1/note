package cn.itcast.pojo;

/**
 * 账户实体类
 *
 * @author lee.siu.wah
 * @version 1.0
 * <p>File Created at 2020-05-13<p>
 */
public class Account {
    // 主键id
    private Integer id;
    // 姓名
    private String name;
    // 余额
    private Float money;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getMoney() {
        return money;
    }

    public void setMoney(Float money) {
        this.money = money;
    }

    @Override
    public String toString() {
        return "Account{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", money=" + money +
                '}';
    }
}
