package cn.itcast.dao;

/**
 * 客户Dao接口
 */
public interface CustomerDao {

    // 保存客户
    void saveCustomer();
}
