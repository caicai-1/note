package cn.itcast.service;

/**
 * 客户service接口
 */
public interface CustomerService {

    // 保存客户
    void saveCustomer();
}