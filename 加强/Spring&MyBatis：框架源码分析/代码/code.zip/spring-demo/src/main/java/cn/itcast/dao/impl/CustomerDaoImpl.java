package cn.itcast.dao.impl;

import cn.itcast.dao.CustomerDao;

/**
 * 客户dao实现类
 */
public class CustomerDaoImpl implements CustomerDao {

    // 保存客户
    public void saveCustomer() {
        System.out.println("正在保存客户操作......");
    }
}
