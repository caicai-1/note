package cn.itcast.service.impl;

import cn.itcast.dao.CustomerDao;
import cn.itcast.service.CustomerService;

/**
 * 客户service实现类
 */
public class CustomerServiceImpl implements CustomerService {
    // 注入客户数据访问接口
    private CustomerDao customerDao;

    // 保存客户
    public void saveCustomer() {
        customerDao.saveCustomer();
    }

    // setter方法(用spring的设值注入)
    public void setCustomerDao(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }
}