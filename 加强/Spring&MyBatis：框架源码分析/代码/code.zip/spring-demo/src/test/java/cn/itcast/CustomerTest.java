package cn.itcast;

import cn.itcast.service.CustomerService;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * 客户测试类
 */
public class CustomerTest {

    @Test
    public void save(){
        // 1. 加载spring配置文件，初始化ioc容器
        ApplicationContext ac = new ClassPathXmlApplicationContext("bean.xml");
        // 2. 从ioc容器中获取bean
        CustomerService customerService = (CustomerService) ac.getBean("customerService");

        // 3. 保存客户
        customerService.saveCustomer();
    }
}